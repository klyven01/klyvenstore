import jwt from 'jsonwebtoken';
export function requireAuth(req,res,next){try{const token=(req.headers.authorization||'').replace('Bearer ','');req.user=jwt.verify(token,process.env.JWT_SECRET);next()}catch{res.status(401).json({error:'Authentication required'})}}
export const requireRole=(...roles)=>(req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({error:'Insufficient permissions'});
export function errorHandler(err,req,res,next){console.error(err);res.status(err.status||500).json({error:err.expose?err.message:'Something went wrong'})}
