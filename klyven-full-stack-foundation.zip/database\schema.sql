-- KLYVEN PostgreSQL schema. Apply using `npm run db:migrate`.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE TYPE user_role AS ENUM ('customer','support','catalog_manager','order_manager','admin','owner');
CREATE TYPE order_status AS ENUM ('pending_payment','payment_verification','confirmed','processing','shipped','out_for_delivery','delivered','cancelled','refunded');
CREATE TYPE payment_method AS ENUM ('manual_upi','cod','gateway');
CREATE TYPE payment_status AS ENUM ('unpaid','verification_required','paid','failed','refunded');
CREATE TYPE review_status AS ENUM ('pending','approved','rejected','hidden');
CREATE TYPE discount_type AS ENUM ('percent','fixed');

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), email citext UNIQUE NOT NULL,
  password_hash text NOT NULL, role user_role NOT NULL DEFAULT 'customer',
  email_verified_at timestamptz, is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE customer_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  first_name text NOT NULL, last_name text, phone text, marketing_opt_in boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE email_verification_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE, expires_at timestamptz NOT NULL, used_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE, expires_at timestamptz NOT NULL, used_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label text NOT NULL DEFAULT 'Home', recipient_name text NOT NULL, phone text NOT NULL,
  line1 text NOT NULL, line2 text, city text NOT NULL, state text NOT NULL, postal_code text NOT NULL,
  country_code char(2) NOT NULL DEFAULT 'IN', is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX one_default_address_per_customer ON addresses(user_id) WHERE is_default;

CREATE TABLE categories (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text UNIQUE NOT NULL, slug text UNIQUE NOT NULL, is_active boolean NOT NULL DEFAULT true);
CREATE TABLE collections (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, slug text UNIQUE NOT NULL, description text, is_active boolean NOT NULL DEFAULT true);
CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), category_id uuid REFERENCES categories(id), collection_id uuid REFERENCES collections(id),
  name text NOT NULL, slug text UNIQUE NOT NULL, description text NOT NULL, short_description text, material text, fit text, gsm text, care_instructions text,
  price_paise integer NOT NULL CHECK(price_paise >= 0), compare_at_price_paise integer CHECK(compare_at_price_paise >= 0),
  is_active boolean NOT NULL DEFAULT false, is_featured boolean NOT NULL DEFAULT false, is_best_seller boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE product_colours (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE, name text NOT NULL, hex_code char(7) NOT NULL, image_url text, sort_order integer NOT NULL DEFAULT 0, UNIQUE(product_id,name));
CREATE TABLE product_sizes (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE, label text NOT NULL CHECK(label IN ('XS','S','M','L','XL','XXL','XXXL')), sort_order integer NOT NULL DEFAULT 0, UNIQUE(product_id,label));
CREATE TABLE product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  colour_id uuid NOT NULL REFERENCES product_colours(id) ON DELETE RESTRICT, size_id uuid NOT NULL REFERENCES product_sizes(id) ON DELETE RESTRICT,
  sku text UNIQUE NOT NULL, stock_quantity integer NOT NULL DEFAULT 0 CHECK(stock_quantity >= 0), is_active boolean NOT NULL DEFAULT true,
  UNIQUE(product_id,colour_id,size_id)
);
CREATE TABLE size_chart_rows (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE, size_label text NOT NULL, chest text, length text, shoulder text, sleeve text, sort_order integer NOT NULL DEFAULT 0);
CREATE TABLE product_images (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE, colour_id uuid REFERENCES product_colours(id) ON DELETE SET NULL, url text NOT NULL, alt_text text, sort_order integer NOT NULL DEFAULT 0);

CREATE TABLE carts (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid UNIQUE REFERENCES users(id) ON DELETE CASCADE, session_id text UNIQUE, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), CHECK(user_id IS NOT NULL OR session_id IS NOT NULL));
CREATE TABLE cart_items (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), cart_id uuid NOT NULL REFERENCES carts(id) ON DELETE CASCADE, variant_id uuid NOT NULL REFERENCES product_variants(id), quantity integer NOT NULL CHECK(quantity > 0), UNIQUE(cart_id,variant_id));
CREATE TABLE wishlists (user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,product_id));

CREATE TABLE coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), code text UNIQUE NOT NULL, type discount_type NOT NULL, value integer NOT NULL CHECK(value > 0),
  min_order_paise integer NOT NULL DEFAULT 0, max_discount_paise integer, starts_at timestamptz, ends_at timestamptz,
  usage_limit integer, per_customer_limit integer, is_active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE coupon_products (coupon_id uuid REFERENCES coupons(id) ON DELETE CASCADE, product_id uuid REFERENCES products(id) ON DELETE CASCADE, PRIMARY KEY(coupon_id,product_id));
CREATE TABLE coupon_categories (coupon_id uuid REFERENCES coupons(id) ON DELETE CASCADE, category_id uuid REFERENCES categories(id) ON DELETE CASCADE, PRIMARY KEY(coupon_id,category_id));

CREATE TABLE store_settings (key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
INSERT INTO store_settings(key,value) VALUES
 ('shipping', '{"freeAbovePaise":149900,"flatPaise":9900}'),
 ('cod', '{"enabled":true,"feePaise":2000,"feeMode":"order"}'),
 ('manual_upi', '{"enabled":true}') ON CONFLICT DO NOTHING;

CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_number text UNIQUE NOT NULL,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL, customer_email citext NOT NULL, customer_phone text NOT NULL,
  shipping_address jsonb NOT NULL, status order_status NOT NULL DEFAULT 'pending_payment',
  payment_method payment_method NOT NULL, payment_status payment_status NOT NULL DEFAULT 'unpaid',
  subtotal_paise integer NOT NULL, discount_paise integer NOT NULL DEFAULT 0, shipping_paise integer NOT NULL DEFAULT 0, cod_fee_paise integer NOT NULL DEFAULT 0, total_paise integer NOT NULL,
  coupon_id uuid REFERENCES coupons(id) ON DELETE SET NULL, tracking_number text, tracking_url text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE order_items (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE, product_id uuid REFERENCES products(id) ON DELETE SET NULL, variant_id uuid REFERENCES product_variants(id) ON DELETE SET NULL, sku text NOT NULL, product_name text NOT NULL, colour_name text NOT NULL, size_label text NOT NULL, unit_price_paise integer NOT NULL, quantity integer NOT NULL CHECK(quantity > 0), line_total_paise integer NOT NULL);
CREATE TABLE payments (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_id uuid UNIQUE NOT NULL REFERENCES orders(id) ON DELETE CASCADE, method payment_method NOT NULL, status payment_status NOT NULL, amount_paise integer NOT NULL, transaction_reference text, verified_by uuid REFERENCES users(id), verified_at timestamptz, notes text, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE order_status_events (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE, status order_status NOT NULL, note text, created_by uuid REFERENCES users(id), created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE coupon_redemptions (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), coupon_id uuid NOT NULL REFERENCES coupons(id), order_id uuid UNIQUE NOT NULL REFERENCES orders(id), user_id uuid REFERENCES users(id), redeemed_at timestamptz NOT NULL DEFAULT now());

CREATE TABLE reviews (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE, user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, order_item_id uuid UNIQUE REFERENCES order_items(id) ON DELETE SET NULL, rating integer NOT NULL CHECK(rating BETWEEN 1 AND 5), title text, comment text NOT NULL, image_url text, is_verified_purchase boolean NOT NULL DEFAULT false, status review_status NOT NULL DEFAULT 'pending', moderated_by uuid REFERENCES users(id), moderated_at timestamptz, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE notifications (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid REFERENCES users(id) ON DELETE SET NULL, order_id uuid REFERENCES orders(id) ON DELETE CASCADE, channel text NOT NULL, template_key text NOT NULL, payload jsonb NOT NULL, status text NOT NULL DEFAULT 'queued', provider_message_id text, sent_at timestamptz, created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX orders_customer_lookup ON orders(customer_email, customer_phone, created_at DESC);
CREATE INDEX order_status_lookup ON orders(status, created_at DESC);
CREATE INDEX variants_product_lookup ON product_variants(product_id, is_active);
