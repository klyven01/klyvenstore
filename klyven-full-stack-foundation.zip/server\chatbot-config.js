// Approved KLYVEN knowledge only. Do not add unverified promises, stock or order data here.
export const chatbotConfig = {
  supportContact: process.env.SUPPORT_EMAIL || 'support@klyven.in',
  approvedAnswers: [
    { match: /track|tracking|where.*order/i, answer: 'You can track your order at /track-order using your order ID and email or mobile number.' },
    { match: /upi|payment/i, answer: 'Manual UPI orders remain in Payment Verification until KLYVEN manually confirms the payment. We never ask for your UPI PIN, OTP, CVV or bank password.' },
    { match: /cod|cash on delivery/i, answer: 'Cash on Delivery availability and the applicable COD fee are shown during checkout.' },
    { match: /size|sizing|fit/i, answer: 'Use the size guide on each product page. Measurements are product-specific.' },
    { match: /shipping|delivery/i, answer: 'Orders are processed before tracking is shared. Tracking information is provided once it exists.' }
  ]
};
export function answerChatbot(message) { const item=chatbotConfig.approvedAnswers.find(x=>x.match.test(message)); return item ? {answer:item.answer,escalate:false} : {answer:`I don’t have a verified answer for that. Please contact ${chatbotConfig.supportContact}.`,escalate:true}; }
